module.exports = {
    docs: {
        fiora: ['getting-start', 'install', 'config', 'script', 'faq', 'changelog'],
        'fiora-app': ['app'],
    },
};
