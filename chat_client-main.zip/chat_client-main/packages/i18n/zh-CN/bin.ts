export const getUserIdDescription = '通过用户名获取 user id';

export const registerDescription = '注册新用户';

export const deleteUserDescription = '删除用户';

export const fixUsersAvatarDescription = '修复用户错误的头像';

export const deleteTodayRegisteredUsersDescription = '删除所有今天创建的新用户';

export const deleteMessagesDescription = '删除所有消息';

export const updateDefaultGroupNameDescription = '修改默认群组名称';

export const doctorDescription = '运行诊断工具检查环境和配置问题';
