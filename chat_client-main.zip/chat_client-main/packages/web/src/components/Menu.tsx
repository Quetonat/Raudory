import Menu, { SubMenu, MenuItem } from 'rc-menu';
import 'rc-menu/assets/index.css';

export { Menu, MenuItem, SubMenu };
