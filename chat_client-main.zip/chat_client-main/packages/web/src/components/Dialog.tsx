import Dialog from 'rc-dialog';
import 'rc-dialog/assets/index.css';

import './Dialog.less';

export default Dialog;
