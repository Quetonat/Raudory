import { Line as LineProgress, Circle as CircleProgress } from 'rc-progress';
import 'rc-progress/assets/index.css';

export { LineProgress, CircleProgress };
