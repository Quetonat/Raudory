declare module 'regex-escape';
